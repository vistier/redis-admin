<?php

	/* set redis variables */
	$config['redis']['host'] = "localhost";
	$config['redis']['port'] = "6379";
	
	/* default admin variables */			
	$config['admin']['user'] = "admin";
	$config['admin']['pass'] = "redis";
	
	/* default dir */
	$config['dir']['home']	 = "/var/www/readmin-x.x.x/";
	
?>