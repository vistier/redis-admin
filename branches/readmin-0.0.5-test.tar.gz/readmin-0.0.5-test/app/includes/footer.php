</table>

<div id="footer">
	<p>&copy; 2010 Redis Admin, Searle Oliveira</p>
	<p>
		<a href="http://twitter.com/searleoliveira">Twitter Updates</a> &nbsp; 
		<a href="http://code.google.com/p/redis-admin">Project Page</a> &nbsp;
		<a href="http://www.opensource.org/licenses/bsd-license.php">BSD License</a>
	</p>
</div>
</body></html>