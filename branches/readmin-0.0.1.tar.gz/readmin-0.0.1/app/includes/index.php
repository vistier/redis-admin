<?php
	header("HTTP/1.1 301 Moved Permanently"); 
	header('location: /');
	exit(0);
?>