</table>

<div id="footer">
	<p>&copy; 2010 Redis Admin</p>
	<p><a href="mailto:project@redisadmin.org">project@redisadmin.org</a></p>
</div>
</body></html>