<?php

	/* default admin variables */			
	$config['admin']['user'] = "admin";
	$config['admin']['pass'] = "redis";
	
	/* default dir */
	$config['dir']['home']	 = "/var/www/sites/bligr.com/";
	
?>